import express from 'express';
import cors from 'cors';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';

const { Pool } = pg;

const app = express();

// --- ENV ---
const JWT_SECRET = process.env.JWT_SECRET || 'CtP2024@SecureKeyRandom987XyZ';
const ADMIN_SECRET_URL = process.env.ADMIN_SECRET_URL || 'cp-admin-2024';
const ADMIN_SECRET_KEY = process.env.ADMIN_SECRET_KEY || 'AdminAccess@2024';
const DATABASE_URL = process.env.DATABASE_URL;
const DATABASE_SSL = process.env.DATABASE_SSL !== 'false' && !DATABASE_URL?.includes('sslmode=disable');

// --- DB ---
const pool = new Pool({
    connectionString: DATABASE_URL,
    ssl: DATABASE_URL && DATABASE_SSL ? { rejectUnauthorized: false } : false
});

// SQL helper: convert ? to $1,$2,...
const q = (sql, params = []) => {
    let i = 1;
    const pgSql = sql.replace(/\?/g, () => `$${i++}`);
    return pool.query(pgSql, params);
};
const dbRun = async (sql, params = []) => { const r = await q(sql, params); return { lastID: 0, changes: r.rowCount }; };
const dbGet = async (sql, params = []) => { const r = await q(sql, params); return r.rows[0]; };
const dbAll = async (sql, params = []) => { const r = await q(sql, params); return r.rows; };

// Helper to log admin/developer actions
const logAction = async (adminId, action, targetUserId, details, ip = '127.0.0.1') => {
    try {
        await dbRun('INSERT INTO admin_logs (admin_id, action, target_user_id, details, ip_address) VALUES (?, ?, ?, ?, ?)',
            [adminId || 0, action, targetUserId || null, details || '', ip]);
    } catch (e) {
        console.error('Failed to log action:', e);
    }
};

// --- MIDDLEWARE ---
app.use(cors({ origin: '*', credentials: true }));
app.use(express.json());

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Требуется авторизация' });
    try {
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') return res.status(401).json({ error: 'Сессия истекла' });
        return res.status(403).json({ error: 'Недействительный токен' });
    }
};

const requireAdmin = (req, res, next) => {
    if (!['admin', 'developer', 'manager'].includes(req.user.role)) {
        return res.status(403).json({ error: 'Доступ запрещён' });
    }
    next();
};

const requireDeveloper = (req, res, next) => {
    if (req.user.role !== 'developer') {
        return res.status(403).json({ error: 'Доступ разрешён только разработчикам' });
    }
    next();
};

const requireActiveAccount = async (req, res, next) => {
    try {
        const user = await dbGet('SELECT is_active FROM users WHERE id = ?', [req.user.id]);
        if (!user || user.is_active !== 1) return res.status(403).json({ error: 'Аккаунт деактивирован' });
        next();
    } catch (e) { res.status(500).json({ error: 'Ошибка сервера' }); }
};

const sanitizeUser = (u) => {
    if (!u) return null;
    return {
        id: u.id,
        email: u.email,
        role: u.role,
        companyName: u.company_name,
        contactPerson: u.contact_person,
        phone: u.phone,
        address: u.address,
        isActive: u.is_active === 1,
        mustChangePassword: !!u.must_change_password,
        createdAt: u.created_at,
        lastLogin: u.last_login
    };
};

// --- HEALTH ---
app.get('/health', (req, res) => res.json({ status: 'ok', path: 'root-health', db: !!DATABASE_URL }));
app.get('/api/health', (req, res) => res.json({ status: 'ok', path: 'api-health', db: !!DATABASE_URL }));

// ===================== AUTH =====================
app.post('/api/auth/login', async (req, res) => {
    try {
        const { login, password } = req.body;
        if (!login || !password) return res.status(400).json({ error: 'Логин и пароль обязательны' });

        const user = await dbGet('SELECT * FROM users WHERE email = ?', [login.toLowerCase()]);
        if (!user) return res.status(401).json({ error: 'Неверный логин или пароль' });
        if (user.is_active !== 1) return res.status(403).json({ error: 'Аккаунт деактивирован' });

        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return res.status(401).json({ error: 'Неверный логин или пароль' });

        await dbRun('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);
        await logAction(user.id, 'login', user.id, `Вход: ${user.email}`, req.ip);

        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role, company: user.company_name },
            JWT_SECRET, { expiresIn: '24h' }
        );

        res.json({
            success: true, token,
            user: sanitizeUser(user)
        });
    } catch (e) { console.error('Login error:', e); res.status(500).json({ error: 'Ошибка сервера' }); }
});

// OTP Login
app.post('/api/auth/login-otp', async (req, res) => {
    try {
        const { code } = req.body;
        if (!code) return res.status(400).json({ error: 'Код обязателен' });

        const otp = await dbGet('SELECT * FROM otp_codes WHERE code = ? AND used = false AND expires_at > CURRENT_TIMESTAMP', [code]);
        if (!otp) return res.status(401).json({ error: 'Недействительный или просроченный одноразовый код' });

        const user = await dbGet('SELECT * FROM users WHERE id = ?', [otp.user_id]);
        if (!user || user.is_active !== 1) return res.status(401).json({ error: 'Пользователь деактивирован' });

        // Mark OTP as used
        await dbRun('UPDATE otp_codes SET used = true, used_at = CURRENT_TIMESTAMP WHERE id = ?', [otp.id]);

        // Force password change
        await dbRun('UPDATE users SET must_change_password = true WHERE id = ?', [user.id]);

        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role, company: user.company_name },
            JWT_SECRET, { expiresIn: '24h' }
        );
        await logAction(user.id, 'otp_login', user.id, `Вход по OTP: ${user.email}`, req.ip);

        res.json({
            success: true, token,
            user: {
                id: user.id, email: user.email, role: user.role,
                companyName: user.company_name, contactPerson: user.contact_person, phone: user.phone
            },
            must_change_password: true
        });
    } catch (e) { console.error('OTP Login error:', e); res.status(500).json({ error: 'Ошибка сервера' }); }
});

// Force password change
app.post('/api/auth/change-password', authenticateToken, async (req, res) => {
    try {
        const { new_password } = req.body;
        if (!new_password || new_password.length < 6) {
            return res.status(400).json({ error: 'Пароль должен содержать минимум 6 символов' });
        }
        const user = await dbGet('SELECT * FROM users WHERE id = ?', [req.user.id]);
        if (!user) return res.status(404).json({ error: 'Пользователь не найден' });

        const hash = await bcrypt.hash(new_password, 12);
        await dbRun('UPDATE users SET password = ?, must_change_password = false WHERE id = ?', [hash, req.user.id]);
        await logAction(req.user.id, 'password_changed', req.user.id, 'Смена пароля', req.ip);

        res.json({ success: true, message: 'Пароль успешно изменён' });
    } catch (e) { console.error('Change password error:', e); res.status(500).json({ error: 'Ошибка сервера' }); }
});

app.post('/api/auth/verify', async (req, res) => {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.status(401).json({ valid: false });
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await dbGet('SELECT * FROM users WHERE id = ?', [decoded.id]);
        if (!user || user.is_active !== 1) return res.status(401).json({ valid: false });
        res.json({ valid: true, user: sanitizeUser(user) });
    } catch (e) { res.status(401).json({ valid: false }); }
});

// Register request
app.post('/api/auth/register-request', async (req, res) => {
    try {
        const { company_name, contact_person, phone, email } = req.body;
        await logAction(0, 'register_request', null, `Заявка: ${company_name}, ${contact_person}, ${phone}, ${email}`, req.ip);
        res.json({ success: true, message: 'Ваша заявка принята! Наш менеджер свяжется с вами в ближайшее время.' });
    } catch (e) { res.status(500).json({ error: 'Ошибка сервера' }); }
});

// ===================== ADMIN =====================
app.post('/api/admin/:secret/login', async (req, res) => {
    try {
        if (req.params.secret !== ADMIN_SECRET_URL) return res.status(404).json({ error: 'Endpoint не найден' });
        const { login, password } = req.body;
        if (!login || !password) return res.status(400).json({ error: 'Логин и пароль обязательны' });

        const user = await dbGet("SELECT * FROM users WHERE email = ? AND role IN ('admin', 'developer', 'manager')", [login.toLowerCase()]);
        if (!user) return res.status(401).json({ error: 'Доступ запрещён' });

        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return res.status(401).json({ error: 'Доступ запрещён' });

        await dbRun('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);
        await logAction(user.id, 'admin_login', user.id, `Вход админа: ${user.email}`, req.ip);

        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role, isAdmin: true },
            JWT_SECRET, { expiresIn: '8h' }
        );

        res.json({ success: true, token, user: sanitizeUser(user) });
    } catch (e) { console.error('Admin login error:', e); res.status(500).json({ error: 'Ошибка сервера' }); }
});

// Admin stats
app.get('/api/admin/stats', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const totalPartners = await dbGet("SELECT COUNT(*) as count FROM users WHERE role IN ('partner', 'client')");
        const activePartners = await dbGet("SELECT COUNT(*) as count FROM users WHERE role IN ('partner', 'client') AND is_active = 1");
        const totalOrders = await dbGet('SELECT COUNT(*) as count FROM orders');
        const totalProducts = await dbGet('SELECT COUNT(*) as count FROM products');
        const activeChats = await dbGet("SELECT COUNT(*) as count FROM chat_conversations WHERE status != 'closed'");
        const pendingOtp = await dbGet("SELECT COUNT(*) as count FROM otp_codes WHERE used = false AND expires_at > CURRENT_TIMESTAMP");

        res.json({
            stats: {
                totalPartners: totalPartners?.count || 0,
                activePartners: activePartners?.count || 0,
                inactivePartners: (totalPartners?.count || 0) - (activePartners?.count || 0),
                totalOrders: totalOrders?.count || 0,
                totalProducts: totalProducts?.count || 0,
                activeChats: activeChats?.count || 0,
                pendingOtp: pendingOtp?.count || 0
            }
        });
    } catch (e) { res.status(500).json({ error: 'Ошибка сервера' }); }
});

// Admin users CRUD
app.get('/api/admin/users', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const users = await dbAll("SELECT * FROM users WHERE role IN ('partner','client','manager') ORDER BY created_at DESC");
        res.json(users.map(sanitizeUser));
    } catch (e) { res.status(500).json({ error: 'Ошибка сервера' }); }
});

app.post('/api/admin/users', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { email, password, role = 'client', companyName, contactPerson, phone, address } = req.body;
        if (!email || !companyName) return res.status(400).json({ error: 'Email и название компании обязательны' });
        const existing = await dbGet('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
        if (existing) return res.status(400).json({ error: 'Этот email уже используется' });
        const hash = await bcrypt.hash(password || 'Temp1234!', 10);
        
        const result = await q("INSERT INTO users (email, password, role, company_name, contact_person, phone, address, is_active, created_by, must_change_password) VALUES ($1, $2, $3, $4, $5, $6, $7, 1, $8, true) RETURNING *",
            [email.toLowerCase(), hash, role, companyName, contactPerson || '', phone || '', address || '', req.user.id]);
        
        const user = result.rows[0];
        await logAction(req.user.id, 'create_user', user.id, `Создан: ${email} (${role})`, req.ip);
        res.json({ user: sanitizeUser(user) });
    } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка сервера' }); }
});

app.put('/api/admin/users/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { companyName, contactPerson, phone, address, isActive, role, newPassword } = req.body;
        const updates = []; const params = [];
        if (companyName !== undefined) { updates.push('company_name = ?'); params.push(companyName); }
        if (contactPerson !== undefined) { updates.push('contact_person = ?'); params.push(contactPerson); }
        if (phone !== undefined) { updates.push('phone = ?'); params.push(phone); }
        if (address !== undefined) { updates.push('address = ?'); params.push(address); }
        if (isActive !== undefined) { updates.push('is_active = ?'); params.push(isActive ? 1 : 0); }
        if (role !== undefined) { updates.push('role = ?'); params.push(role); }
        if (newPassword) { updates.push('password = ?'); params.push(await bcrypt.hash(newPassword, 12)); }
        if (updates.length === 0) return res.status(400).json({ error: 'Нет данных' });

        let i = 1;
        const pgUpdates = updates.map(u => u.replace('?', `$${i++}`));
        params.push(id);
        
        const result = await pool.query(`UPDATE users SET ${pgUpdates.join(', ')} WHERE id = $${i} RETURNING *`, params);
        const user = result.rows[0];
        await logAction(req.user.id, 'update_user', id, `Обновлён: ${user.email}`, req.ip);
        res.json({ user: sanitizeUser(user) });
    } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка сервера' }); }
});

app.delete('/api/admin/users/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const result = await q('UPDATE users SET is_active = 0 WHERE id = $1 RETURNING *', [req.params.id]);
        const user = result.rows[0];
        await logAction(req.user.id, 'deactivate_user', req.params.id, `Деактивирован: ${user?.email}`, req.ip);
        res.json({ success: true, message: 'Деактивирован' });
    } catch (e) { res.status(500).json({ error: 'Ошибка сервера' }); }
});

// Admin OTP Generator
app.post('/api/admin/generate-otp', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { user_id } = req.body;
        const user = await dbGet('SELECT * FROM users WHERE id = ?', [user_id]);
        if (!user) return res.status(404).json({ error: 'Пользователь не найден' });

        // Invalidate old OTPs for this user
        await dbRun('UPDATE otp_codes SET used = true WHERE user_id = ? AND used = false', [user_id]);

        const code = crypto.randomBytes(4).toString('hex').toUpperCase(); // 8 chars
        const expires_at = new Date(Date.now() + 24 * 60 * 60 * 1000);
        
        await dbRun('INSERT INTO otp_codes (code, user_id, created_by, expires_at) VALUES (?, ?, ?, ?)',
            [code, user_id, req.user.id, expires_at]);

        await logAction(req.user.id, 'generate_otp', user_id, `OTP для ${user.email}: ${code}`, req.ip);

        res.json({ code, expires_at: expires_at.toISOString(), user_email: user.email });
    } catch (err) { console.error(err); res.status(500).json({ error: 'Ошибка сервера' }); }
});

// Admin products
app.get('/api/admin/products', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const products = await dbAll('SELECT * FROM products ORDER BY name ASC');
        res.json(products);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.post('/api/admin/products', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { name, price, stock, manufacturer, category, description, discount, discount_label } = req.body;
        const result = await q('INSERT INTO products (guid, name, price, stock, manufacturer, category, description, is_active, discount, discount_label) VALUES ($1, $2, $3, $4, $5, $6, $7, 1, $8, $9) RETURNING *',
            ['prod-' + Date.now(), name, price, stock, manufacturer, category, description || '', discount || 0, discount_label || null]);
        await logAction(req.user.id, 'create_product', null, `Товар: ${name}`, req.ip);
        res.json(result.rows[0]);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.put('/api/admin/products/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { name, price, stock, manufacturer, category, description, is_active, discount, discount_label } = req.body;
        
        const updates = []; const params = [];
        if (name !== undefined) { updates.push('name = ?'); params.push(name); }
        if (price !== undefined) { updates.push('price = ?'); params.push(price); }
        if (stock !== undefined) { updates.push('stock = ?'); params.push(stock); }
        if (manufacturer !== undefined) { updates.push('manufacturer = ?'); params.push(manufacturer); }
        if (category !== undefined) { updates.push('category = ?'); params.push(category); }
        if (description !== undefined) { updates.push('description = ?'); params.push(description); }
        if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active ? 1 : 0); }
        if (discount !== undefined) { updates.push('discount = ?'); params.push(discount); }
        if (discount_label !== undefined) { updates.push('discount_label = ?'); params.push(discount_label); }

        if (updates.length === 0) return res.status(400).json({ error: 'Нет данных' });

        let i = 1;
        const pgUpdates = updates.map(u => u.replace('?', `$${i++}`));
        params.push(id);
        
        const result = await pool.query(`UPDATE products SET ${pgUpdates.join(', ')} WHERE id = $${i} RETURNING *`, params);
        await logAction(req.user.id, 'update_product', null, `Товар обновлён: ${result.rows[0]?.name}`, req.ip);
        res.json(result.rows[0]);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

// ===================== PRODUCTS =====================
app.get('/api/products', async (req, res) => {
    try {
        const { category, search } = req.query;
        let sql = 'SELECT * FROM products WHERE is_active = 1';
        const params = [];
        if (category) { sql += ' AND category = ?'; params.push(category); }
        if (search) { sql += ' AND (name ILIKE ? OR manufacturer ILIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
        sql += ' ORDER BY name';
        const products = await dbAll(sql, params);
        res.json(products);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/products/category/:category', async (req, res) => {
    try {
        const products = await dbAll('SELECT * FROM products WHERE category = ? AND is_active = 1 ORDER BY name', [req.params.category]);
        res.json(products);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/products/:id', async (req, res) => {
    try {
        const product = await dbGet('SELECT * FROM products WHERE id = ? AND is_active = 1', [req.params.id]);
        if (!product) return res.status(404).json({ error: 'Товар не найден' });
        res.json(product);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

// ===================== USERS =====================
app.get('/api/users/me', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const user = await dbGet('SELECT * FROM users WHERE id = ?', [req.user.id]);
        if (!user) return res.status(404).json({ error: 'Не найден' });
        res.json(sanitizeUser(user));
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.put('/api/users/me', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const { contact_person, phone, address, company_name } = req.body;
        await dbRun('UPDATE users SET contact_person = COALESCE(?, contact_person), phone = COALESCE(?, phone), address = COALESCE(?, address), company_name = COALESCE(?, company_name) WHERE id = ?',
            [contact_person, phone, address, company_name, req.user.id]);
        const user = await dbGet('SELECT * FROM users WHERE id = ?', [req.user.id]);
        res.json(sanitizeUser(user));
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

// ===================== ORDERS =====================
app.get('/api/orders', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const orders = await dbAll('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
        const ordersWithItems = [];
        for (const o of orders) {
            const items = await dbAll('SELECT * FROM order_items WHERE order_id = ?', [o.id]);
            ordersWithItems.push({
                id: o.id, orderNumber: o.order_number, status: o.status,
                total_amount: o.total_amount, items_count: o.items_count,
                delivery_address: o.delivery_address, created_at: o.created_at,
                items: items
            });
        }
        res.json(ordersWithItems);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/orders/:id', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const order = await dbGet('SELECT * FROM orders WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        if (!order) return res.status(404).json({ error: 'Заказ не найден' });
        const items = await dbAll('SELECT * FROM order_items WHERE order_id = ?', [order.id]);
        res.json({
            id: order.id, orderNumber: order.order_number, status: order.status,
            total_amount: order.total_amount, items_count: order.items_count,
            delivery_address: order.delivery_address, created_at: order.created_at,
            items: items
        });
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.post('/api/orders', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const cartItems = await dbAll('SELECT * FROM cart_items WHERE user_id = ?', [req.user.id]);
        if (!cartItems || cartItems.length === 0) return res.status(400).json({ error: 'Корзина пуста' });
        const total = cartItems.reduce((s, i) => s + (i.price * i.quantity), 0);
        const orderNumber = `ORD-${Date.now().toString(36).toUpperCase()}`;

        const result = await q("INSERT INTO orders (user_id, order_number, status, total_amount, items_count, delivery_address) VALUES ($1, $2, 'pending', $3, $4, $5) RETURNING id, order_number, status, total_amount, items_count, delivery_address, created_at",
            [req.user.id, orderNumber, total, cartItems.length, req.body.delivery_address || '']);
        const order = result.rows[0];

        for (const item of cartItems) {
            await q('INSERT INTO order_items (order_id, product_id, product_name, quantity, price, total) VALUES ($1, $2, $3, $4, $5, $6)',
                [order.id, item.product_id, item.product_name, item.quantity, item.price, item.price * item.quantity]);
        }
        await dbRun('DELETE FROM cart_items WHERE user_id = ?', [req.user.id]);
        await logAction(req.user.id, 'create_order', req.user.id, `Заказ ${order.order_number}: ${total} UZS`, req.ip);
        res.json(order);
    } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка' }); }
});

app.put('/api/orders/:id/cancel', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const order = await dbGet('SELECT * FROM orders WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        if (!order) return res.status(404).json({ error: 'Заказ не найден' });
        if (order.status !== 'pending') return res.status(400).json({ error: 'Можно отменить только ожидающий заказ' });
        
        const result = await q("UPDATE orders SET status = 'cancelled' WHERE id = $1 RETURNING *", [req.params.id]);
        await logAction(req.user.id, 'cancel_order', req.user.id, `Отменён: ${order.order_number}`, req.ip);
        res.json(result.rows[0]);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

// ===================== CART =====================
app.get('/api/cart', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const items = await dbAll('SELECT * FROM cart_items WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
        res.json(items.map(i => ({
            id: i.id, product_id: i.product_id, product_name: i.product_name,
            quantity: i.quantity, price: i.price
        })));
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.post('/api/cart', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const { product_id, quantity = 1 } = req.body;
        const product = await dbGet('SELECT * FROM products WHERE id = ? AND is_active = 1', [product_id]);
        if (!product) return res.status(404).json({ error: 'Товар не найден' });

        const existing = await dbGet('SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?', [req.user.id, product_id]);
        if (existing) {
            const updated = await q('UPDATE cart_items SET quantity = quantity + $1 WHERE id = $2 RETURNING *', [quantity, existing.id]);
            return res.json(updated.rows[0]);
        }

        const result = await q('INSERT INTO cart_items (user_id, product_id, product_name, quantity, price) VALUES ($1, $2, $3, $4, $5) RETURNING *',
            [req.user.id, product_id, product.name, quantity, product.price]);
        res.json(result.rows[0]);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.put('/api/cart/:id', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const result = await q('UPDATE cart_items SET quantity = $1 WHERE id = $2 AND user_id = $3 RETURNING *', [req.body.quantity, req.params.id, req.user.id]);
        res.json(result.rows[0]);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.delete('/api/cart/:id', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        await dbRun('DELETE FROM cart_items WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
        res.json({ message: 'Удалено' });
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.delete('/api/cart', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        await dbRun('DELETE FROM cart_items WHERE user_id = ?', [req.user.id]);
        res.json({ message: 'Корзина очищена' });
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

// ===================== CABINET DATA =====================
app.get('/api/cabinet/debts', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const debt = await dbGet('SELECT * FROM debts WHERE user_id = ?', [req.user.id]);
        res.json(debt || { amount: 0, credit_limit: 0, overdue_amount: 0, currency: 'UZS' });
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/cabinet/documents', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const docs = await dbAll('SELECT * FROM documents WHERE user_id = ? ORDER BY date DESC', [req.user.id]);
        res.json(docs);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/cabinet/claims', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const claims = await dbAll('SELECT * FROM claims WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
        res.json(claims);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.post('/api/cabinet/claims', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const result = await q("INSERT INTO claims (user_id, order_id, product_id, type, description, status) VALUES ($1, $2, $3, $4, $5, 'open') RETURNING *",
            [req.user.id, req.body.order_id || null, req.body.product_id || null, req.body.type, req.body.description]);
        res.json(result.rows[0]);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/cabinet/certificates', authenticateToken, requireActiveAccount, async (req, res) => {
    try {
        const certs = await dbAll('SELECT * FROM certificates ORDER BY created_at DESC');
        res.json(certs);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

// ===================== CHAT SYSTEM =====================
app.post('/api/chat/start', authenticateToken, async (req, res) => {
    try {
        let conv = await dbGet("SELECT * FROM chat_conversations WHERE user_id = ? AND status != 'closed'", [req.user.id]);
        if (!conv) {
            const resInsert = await q("INSERT INTO chat_conversations (user_id, status) VALUES ($1, 'ai') RETURNING id, status, user_id, created_at, updated_at", [req.user.id]);
            conv = resInsert.rows[0];
            
            // Seed initial AI message
            await dbRun("INSERT INTO chat_messages (conversation_id, sender_type, message) VALUES (?, 'ai', ?)",
                [conv.id, 'Здравствуйте! Я виртуальный помощник Curatio Pharm. Задайте мне вопрос, и я постараюсь помочь. Если потребуется, вы всегда можете связаться с оператором.']);
        }
        const messages = await dbAll("SELECT * FROM chat_messages WHERE conversation_id = ? ORDER BY created_at ASC", [conv.id]);
        res.json({ conversation: conv, messages });
    } catch (err) { console.error(err); res.status(500).json({ error: 'Ошибка сервера' }); }
});

app.get('/api/chat/messages/:conversationId', authenticateToken, async (req, res) => {
    try {
        const conv = await dbGet("SELECT * FROM chat_conversations WHERE id = ?", [req.params.conversationId]);
        if (!conv) return res.status(404).json({ error: 'Чат не найден' });
        const messages = await dbAll("SELECT * FROM chat_messages WHERE conversation_id = ? ORDER BY created_at ASC", [conv.id]);
        res.json({ conversation: conv, messages });
    } catch (err) { console.error(err); res.status(500).json({ error: 'Ошибка сервера' }); }
});

app.post('/api/chat/send', authenticateToken, async (req, res) => {
    try {
        const { conversation_id, message } = req.body;
        const conv = await dbGet("SELECT * FROM chat_conversations WHERE id = ?", [conversation_id]);
        if (!conv) return res.status(404).json({ error: 'Чат не найден' });

        // Save user message
        const resUserMsg = await q("INSERT INTO chat_messages (conversation_id, sender_type, sender_id, message) VALUES ($1, 'user', $2, $3) RETURNING *",
            [conversation_id, req.user.id, message]);
        const userMsg = resUserMsg.rows[0];
        await dbRun("UPDATE chat_conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ?", [conversation_id]);

        let aiResponse = null;
        if (conv.status === 'ai') {
            const lowerMsg = message.toLowerCase();
            const faq = [
                { keywords: ['доставк', 'доставит', 'транспорт'], answer: 'Мы осуществляем доставку по всему Узбекистану. Доставка в регионы обычно занимает от 24 до 48 часов.' },
                { keywords: ['адрес', 'где', 'находит', 'офис', 'склад'], answer: 'Наш складской комплекс расположен по адресу: г. Ташкент, Юнусабадский р-н, ул. Карима Зарипова, 3.' },
                { keywords: ['время', 'часы', 'работ', 'режим'], answer: 'Мы работаем с понедельника по пятницу с 09:00 до 18:00.' },
                { keywords: ['контакт', 'телефон', 'связ', 'номер'], answer: 'Вы можете связаться с нами по телефону +998 (71) 207-01-52 или написать на info@cpharm.uz.' },
                { keywords: ['сертификат', 'документ', 'лиценз'], answer: 'Все наши товары сертифицированы в соответствии с требованиями GDP и ISO 9001:2015. Сертификаты доступны в личном кабинете.' }
            ];
            const faqMatch = faq.find(f => f.keywords.some(k => lowerMsg.includes(k)));
            const aiText = faqMatch
                ? faqMatch.answer
                : 'К сожалению, я не могу ответить на этот вопрос. Пожалуйста, нажмите «Связаться с оператором» для получения помощи от специалиста.';

            const resAiMsg = await q("INSERT INTO chat_messages (conversation_id, sender_type, message) VALUES ($1, 'ai', $2) RETURNING *",
                [conversation_id, aiText]);
            aiResponse = resAiMsg.rows[0];
        }

        res.json({ userMessage: userMsg, aiResponse });
    } catch (err) { console.error(err); res.status(500).json({ error: 'Ошибка сервера' }); }
});

app.post('/api/chat/request-operator', authenticateToken, async (req, res) => {
    try {
        const { conversation_id } = req.body;
        const conv = await dbGet("SELECT * FROM chat_conversations WHERE id = ?", [conversation_id]);
        if (!conv) return res.status(404).json({ error: 'Чат не найден' });

        await dbRun("UPDATE chat_conversations SET status = 'operator', updated_at = CURRENT_TIMESTAMP WHERE id = ?", [conversation_id]);

        const sysText = '🔔 Вы были переключены на оператора. Пожалуйста, подождите — специалист скоро ответит.';
        const resSysMsg = await q("INSERT INTO chat_messages (conversation_id, sender_type, message) VALUES ($1, 'ai', $2) RETURNING *",
            [conversation_id, sysText]);

        res.json({ conversation: { ...conv, status: 'operator' }, message: resSysMsg.rows[0] });
    } catch (err) { console.error(err); res.status(500).json({ error: 'Ошибка сервера' }); }
});

// Admin chat endpoints
app.get('/api/admin/chats', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const convs = await dbAll("SELECT * FROM chat_conversations ORDER BY updated_at DESC");
        const fullConvs = [];
        for (const c of convs) {
            const user = await dbGet("SELECT id, email, company_name, contact_person, phone FROM users WHERE id = ?", [c.user_id]);
            const msgs = await dbAll("SELECT * FROM chat_messages WHERE conversation_id = ? ORDER BY created_at ASC", [c.id]);
            const lastMsg = msgs[msgs.length - 1];
            fullConvs.push({
                ...c,
                user: sanitizeUser(user),
                last_message: lastMsg,
                message_count: msgs.length
            });
        }
        res.json(fullConvs);
    } catch (err) { console.error(err); res.status(500).json({ error: 'Ошибка сервера' }); }
});

app.post('/api/admin/chats/:id/reply', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const conv = await dbGet("SELECT * FROM chat_conversations WHERE id = ?", [req.params.id]);
        if (!conv) return res.status(404).json({ error: 'Чат не найден' });

        const result = await q("INSERT INTO chat_messages (conversation_id, sender_type, sender_id, message) VALUES ($1, 'operator', $2, $3) RETURNING *",
            [conv.id, req.user.id, req.body.message]);
        
        await dbRun("UPDATE chat_conversations SET status = 'operator', updated_at = CURRENT_TIMESTAMP WHERE id = ?", [conv.id]);
        res.json(result.rows[0]);
    } catch (err) { console.error(err); res.status(500).json({ error: 'Ошибка сервера' }); }
});

app.put('/api/admin/chats/:id/close', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const conv = await dbGet("SELECT * FROM chat_conversations WHERE id = ?", [req.params.id]);
        if (!conv) return res.status(404).json({ error: 'Чат не найден' });
        await dbRun("UPDATE chat_conversations SET status = 'closed', updated_at = CURRENT_TIMESTAMP WHERE id = ?", [conv.id]);
        res.json({ message: 'Чат закрыт' });
    } catch (err) { console.error(err); res.status(500).json({ error: 'Ошибка сервера' }); }
});

// Support settings
app.get('/api/admin/support-settings', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const settings = await dbGet('SELECT * FROM support_settings ORDER BY id DESC LIMIT 1');
        res.json(settings || { phone: '+998 (71) 207-01-52', email: 'info@cpharm.uz', work_hours: 'Пн-Пт 09:00-18:00' });
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.put('/api/admin/support-settings', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { phone, email, work_hours } = req.body;
        const existing = await dbGet('SELECT id FROM support_settings LIMIT 1');
        if (existing) {
            await dbRun('UPDATE support_settings SET phone = ?, email = ?, work_hours = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
                [phone, email, work_hours, req.user.id, existing.id]);
        } else {
            await dbRun('INSERT INTO support_settings (phone, email, work_hours, updated_by) VALUES (?, ?, ?, ?)',
                [phone, email, work_hours, req.user.id]);
        }
        const settings = await dbGet('SELECT * FROM support_settings LIMIT 1');
        res.json(settings);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/support-settings', async (req, res) => {
    try {
        const settings = await dbGet('SELECT * FROM support_settings LIMIT 1');
        res.json(settings || { phone: '+998 (71) 207-01-52', email: 'info@cpharm.uz', work_hours: 'Пн-Пт 09:00-18:00' });
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

// ===================== EVENTS SYSTEM =====================
app.get('/api/events/active', async (req, res) => {
    try {
        const active = await dbAll('SELECT * FROM events WHERE is_active = true AND starts_at <= CURRENT_TIMESTAMP AND ends_at >= CURRENT_TIMESTAMP');
        res.json(active);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/dev/events', authenticateToken, requireDeveloper, async (req, res) => {
    try {
        const events = await dbAll('SELECT * FROM events ORDER BY created_at DESC');
        res.json(events);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.post('/api/dev/events', authenticateToken, requireDeveloper, async (req, res) => {
    try {
        const { title, description, type, image_url, background_color, text_color, link_url, starts_at, ends_at } = req.body;
        const result = await q('INSERT INTO events (title, description, type, image_url, background_color, text_color, link_url, starts_at, ends_at, created_by) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *',
            [title, description || '', type || 'banner', image_url || '', background_color || '#10b981', text_color || '#ffffff', link_url || '', starts_at, ends_at, req.user.id]);
        const event = result.rows[0];
        await logAction(req.user.id, 'create_event', null, `Создано событие: ${event.title}`, req.ip);
        res.json(event);
    } catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
});

app.put('/api/dev/events/:id', authenticateToken, requireDeveloper, async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description, type, image_url, background_color, text_color, link_url, starts_at, ends_at, is_active } = req.body;
        
        const updates = []; const params = [];
        if (title !== undefined) { updates.push('title = ?'); params.push(title); }
        if (description !== undefined) { updates.push('description = ?'); params.push(description); }
        if (type !== undefined) { updates.push('type = ?'); params.push(type); }
        if (image_url !== undefined) { updates.push('image_url = ?'); params.push(image_url); }
        if (background_color !== undefined) { updates.push('background_color = ?'); params.push(background_color); }
        if (text_color !== undefined) { updates.push('text_color = ?'); params.push(text_color); }
        if (link_url !== undefined) { updates.push('link_url = ?'); params.push(link_url); }
        if (starts_at !== undefined) { updates.push('starts_at = ?'); params.push(starts_at); }
        if (ends_at !== undefined) { updates.push('ends_at = ?'); params.push(ends_at); }
        if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active); }

        if (updates.length === 0) return res.status(400).json({ error: 'Нет данных' });

        let i = 1;
        const pgUpdates = updates.map(u => u.replace('?', `$${i++}`));
        params.push(id);
        
        const result = await pool.query(`UPDATE events SET ${pgUpdates.join(', ')} WHERE id = $${i} RETURNING *`, params);
        res.json(result.rows[0]);
    } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/dev/events/:id', authenticateToken, requireDeveloper, async (req, res) => {
    try {
        await dbRun('DELETE FROM events WHERE id = ?', [req.params.id]);
        res.json({ message: 'Событие удалено' });
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

// ===================== DEVELOPER PANEL =====================
app.get('/api/dev/logs', authenticateToken, requireDeveloper, async (req, res) => {
    try {
        const logs = await dbAll('SELECT * FROM admin_logs ORDER BY created_at DESC');
        const fullLogs = [];
        for (const log of logs) {
            const admin = await dbGet('SELECT contact_person, email FROM users WHERE id = ?', [log.admin_id]);
            const target = log.target_user_id ? await dbGet('SELECT contact_person, email FROM users WHERE id = ?', [log.target_user_id]) : null;
            fullLogs.push({
                id: log.id,
                admin_id: log.admin_id,
                action: log.action,
                target_user_id: log.target_user_id,
                details: log.details,
                ip_address: log.ip_address,
                created_at: log.created_at,
                admin_name: admin ? admin.contact_person || admin.email : 'System',
                target_name: target ? target.contact_person || target.email : null
            });
        }
        res.json(fullLogs);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/dev/stats', authenticateToken, requireDeveloper, async (req, res) => {
    try {
        const usersCount = await dbGet("SELECT COUNT(*) as total, COUNT(CASE WHEN is_active=1 THEN 1 END) as active, COUNT(CASE WHEN role='client' OR role='partner' THEN 1 END) as clients, COUNT(CASE WHEN role='admin' THEN 1 END) as admins FROM users");
        const productsCount = await dbGet("SELECT COUNT(*) as total, COUNT(CASE WHEN is_active=1 THEN 1 END) as active FROM products");
        const ordersCount = await dbGet("SELECT COUNT(*) as total, COUNT(CASE WHEN status='pending' THEN 1 END) as pending, COUNT(CASE WHEN status='completed' THEN 1 END) as completed, COALESCE(SUM(total_amount), 0) as revenue FROM orders");
        const chatsCount = await dbGet("SELECT COUNT(*) as total, COUNT(CASE WHEN status!='closed' THEN 1 END) as active FROM chat_conversations");
        const eventsCount = await dbGet("SELECT COUNT(*) as total, COUNT(CASE WHEN is_active=true THEN 1 END) as active FROM events");
        const otpCount = await dbGet("SELECT COUNT(*) as total, COUNT(CASE WHEN used=false THEN 1 END) as unused FROM otp_codes");
        const logsCount = await dbGet("SELECT COUNT(*) as count FROM admin_logs");

        res.json({
            users: { total: parseInt(usersCount.total) || 0, active: parseInt(usersCount.active) || 0, clients: parseInt(usersCount.clients) || 0, admins: parseInt(usersCount.admins) || 0 },
            products: { total: parseInt(productsCount.total) || 0, active: parseInt(productsCount.active) || 0 },
            orders: { total: parseInt(ordersCount.total) || 0, pending: parseInt(ordersCount.pending) || 0, completed: parseInt(ordersCount.completed) || 0 },
            revenue: parseFloat(ordersCount.revenue) || 0,
            chats: { total: parseInt(chatsCount.total) || 0, active: parseInt(chatsCount.active) || 0 },
            events: { total: parseInt(eventsCount.total) || 0, active: parseInt(eventsCount.active) || 0 },
            otp: { total: parseInt(otpCount.total) || 0, unused: parseInt(otpCount.unused) || 0 },
            logs: parseInt(logsCount.count) || 0
        });
    } catch (e) { console.error(e); res.status(500).json({ error: 'Ошибка' }); }
});

app.get('/api/dev/users-full', authenticateToken, requireDeveloper, async (req, res) => {
    try {
        const users = await dbAll("SELECT * FROM users ORDER BY created_at DESC");
        const fullUsers = [];
        for (const u of users) {
            const count = await dbGet('SELECT COUNT(*) as c FROM orders WHERE user_id = ?', [u.id]);
            fullUsers.push({
                ...sanitizeUser(u),
                orders_count: parseInt(count?.c) || 0
            });
        }
        res.json(fullUsers);
    } catch (e) { res.status(500).json({ error: 'Ошибка' }); }
});

// ===================== INIT DB (developer/public) =====================
app.get('/api/init-db', async (req, res) => {
    try {
        // Create base tables
        await pool.query(`CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'client' CHECK(role IN ('admin','manager','client','partner','developer','hr')),
            company_name TEXT, contact_person TEXT, phone TEXT, address TEXT,
            is_active INTEGER DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP, created_by INTEGER, must_change_password BOOLEAN DEFAULT false
        )`);
        
        // Ensure must_change_password exists (in case table was created previously without it)
        await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN DEFAULT false`);

        await pool.query(`CREATE TABLE IF NOT EXISTS products (
            id SERIAL PRIMARY KEY, guid TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
            manufacturer TEXT, category TEXT, price DECIMAL(10,2) NOT NULL DEFAULT 0,
            stock INTEGER NOT NULL DEFAULT 0, description TEXT, is_active INTEGER DEFAULT 1,
            discount INTEGER DEFAULT 0, discount_label TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, synced_at TIMESTAMP
        )`);
        await pool.query(`CREATE TABLE IF NOT EXISTS orders (
            id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
            order_number TEXT UNIQUE NOT NULL, status TEXT DEFAULT 'pending', total_amount DECIMAL(15,2) NOT NULL,
            items_count INTEGER NOT NULL, delivery_address TEXT, contact_phone TEXT, notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`);
        await pool.query(`CREATE TABLE IF NOT EXISTS order_items (
            id SERIAL PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
            product_id INTEGER NOT NULL, product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
            price DECIMAL(10,2) NOT NULL, total DECIMAL(15,2) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`);
        await pool.query(`CREATE TABLE IF NOT EXISTS cart_items (
            id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            product_id INTEGER NOT NULL, product_name TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 1,
            price DECIMAL(10,2) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id, product_id)
        )`);
        await pool.query(`CREATE TABLE IF NOT EXISTS debts (
            id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
            amount DECIMAL(15,2) NOT NULL DEFAULT 0, credit_limit DECIMAL(15,2) NOT NULL DEFAULT 0,
            overdue_amount DECIMAL(15,2) NOT NULL DEFAULT 0, currency TEXT DEFAULT 'UZS',
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`);
        await pool.query(`CREATE TABLE IF NOT EXISTS documents (
            id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            number TEXT NOT NULL, type TEXT NOT NULL, date DATE NOT NULL,
            amount DECIMAL(15,2) NOT NULL DEFAULT 0, status TEXT DEFAULT 'unpaid',
            file_url TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`);
        await pool.query(`CREATE TABLE IF NOT EXISTS claims (
            id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            order_id INTEGER, product_id INTEGER, type TEXT NOT NULL,
            status TEXT DEFAULT 'new', description TEXT, admin_comment TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`);
        await pool.query(`CREATE TABLE IF NOT EXISTS certificates (
            id SERIAL PRIMARY KEY, product_id INTEGER, name TEXT NOT NULL,
            file_url TEXT NOT NULL, expiration_date DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`);
        await pool.query(`CREATE TABLE IF NOT EXISTS login_attempts (
            id SERIAL PRIMARY KEY, ip_address TEXT NOT NULL, email TEXT,
            success INTEGER DEFAULT 0, attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`);
        await pool.query(`CREATE TABLE IF NOT EXISTS admin_logs (
            id SERIAL PRIMARY KEY, admin_id INTEGER NOT NULL, action TEXT NOT NULL,
            target_user_id INTEGER, details TEXT, ip_address TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`);

        // Create new feature tables
        await pool.query(`CREATE TABLE IF NOT EXISTS otp_codes (
            id SERIAL PRIMARY KEY, code VARCHAR(12) UNIQUE NOT NULL,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
            used BOOLEAN DEFAULT false, used_at TIMESTAMP,
            expires_at TIMESTAMP NOT NULL, created_at TIMESTAMP DEFAULT NOW()
        )`);

        await pool.query(`CREATE TABLE IF NOT EXISTS chat_conversations (
            id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            status VARCHAR(20) DEFAULT 'ai', created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        )`);

        await pool.query(`CREATE TABLE IF NOT EXISTS chat_messages (
            id SERIAL PRIMARY KEY, conversation_id INTEGER REFERENCES chat_conversations(id) ON DELETE CASCADE,
            sender_type VARCHAR(20) NOT NULL, sender_id INTEGER,
            message TEXT NOT NULL, created_at TIMESTAMP DEFAULT NOW()
        )`);

        await pool.query(`CREATE TABLE IF NOT EXISTS support_settings (
            id SERIAL PRIMARY KEY, phone VARCHAR(50), email VARCHAR(100),
            work_hours VARCHAR(100), updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
            updated_at TIMESTAMP DEFAULT NOW()
        )`);

        await pool.query(`CREATE TABLE IF NOT EXISTS events (
            id SERIAL PRIMARY KEY, title VARCHAR(255) NOT NULL, description TEXT,
            type VARCHAR(30) DEFAULT 'banner', image_url TEXT,
            background_color VARCHAR(20), text_color VARCHAR(20), link_url TEXT,
            is_active BOOLEAN DEFAULT true, starts_at TIMESTAMP NOT NULL, ends_at TIMESTAMP NOT NULL,
            created_by INTEGER REFERENCES users(id) ON DELETE SET NULL, created_at TIMESTAMP DEFAULT NOW()
        )`);

        // Seed support_settings if empty
        const sc = await dbGet('SELECT count(*) as c FROM support_settings');
        if (parseInt(sc.c) === 0) {
            await dbRun('INSERT INTO support_settings (phone, email, work_hours) VALUES (?, ?, ?)',
                ['+998 (71) 207-01-52', 'info@cpharm.uz', 'Пн-Пт 09:00-18:00']);
        }

        // Seed users
        // 1. Admin
        const admin = await dbGet("SELECT id FROM users WHERE email = 'admincp'");
        if (!admin) {
            const hash = await bcrypt.hash('#wtkm999$', 12);
            await dbRun("INSERT INTO users (email, password, role, company_name, contact_person, phone, address, is_active) VALUES (?, ?, 'admin', 'CuratioPharm', 'Super Administrator', '+998712070152', 'Ташкент', 1)", ['admincp', hash]);
        }

        // 2. Developer
        const developer = await dbGet("SELECT id FROM users WHERE email = 'developer@cpharm.uz'");
        if (!developer) {
            const hash = await bcrypt.hash('DevAccess2024!', 12);
            await dbRun("INSERT INTO users (email, password, role, company_name, contact_person, phone, address, is_active) VALUES (?, ?, 'developer', 'Curatio Pharm Dev', 'System Developer', '+998000000000', 'Tashkent', 1)", ['developer@cpharm.uz', hash]);
        }

        // 3. Manager
        const manager = await dbGet("SELECT id FROM users WHERE email = 'manager@cpharm.uz'");
        if (!manager) {
            const hash = await bcrypt.hash('Manager2024!', 12);
            await dbRun("INSERT INTO users (email, password, role, company_name, contact_person, phone, address, is_active) VALUES (?, ?, 'manager', 'Curatio Pharm', 'Менеджер Отдела', '+998712070152', 'Ташкент', 1)", ['manager@cpharm.uz', hash]);
        }

        // 4. Default client
        const client = await dbGet("SELECT id FROM users WHERE email = 'client1@apteka1.uz'");
        if (!client) {
            const hash = await bcrypt.hash('Client2024!', 12);
            const res = await q("INSERT INTO users (email, password, role, company_name, contact_person, phone, address, is_active) VALUES ($1, $2, 'client', 'Аптека \"Здоровье\" №1', 'Иванов И.И.', '+998 90 123-45-67', 'Ташкент', 1) RETURNING id", ['client1@apteka1.uz', hash]);
            const uId = res.rows[0].id;
            
            // Add debt for client
            await dbRun('INSERT INTO debts (user_id, amount, credit_limit, overdue_amount) VALUES (?, 4500000, 10000000, 0)', [uId]);
            // Add an invoice document
            await dbRun("INSERT INTO documents (user_id, number, type, date, amount, status) VALUES (?, 'INV-2024-001', 'Накладная', '2026-05-15', 1200000, 'Частично оплачен')", [uId]);
        }

        // Seed products
        const pc = await dbGet('SELECT count(*) as c FROM products');
        if (parseInt(pc.c) === 0) {
            const prods = [
                ['prod-001', 'Амоксициллин 500 мг', 'Узфарм', 'Антибиотики', 15000, 1200, 'Антибиотик широкого спектра действия'],
                ['prod-002', 'Азитромицин 500 мг', 'Узфарм', 'Антибиотики', 25000, 800, 'Макролидный антибиотик широкого спектра действия'],
                ['prod-003', 'Цефтриаксон 1.0 г', 'Фармстандарт', 'Антибиотики', 18000, 1500, 'Цефалоспориновый антибиотик III поколения'],
                ['prod-006', 'Витамин C 500 мг', 'Витамакс', 'Витамины', 8000, 2000, 'Аскорбиновая кислота, укрепление иммунитета'],
                ['prod-007', 'Комплекс Витавит', 'Витамакс', 'Витамины', 35000, 750, 'Сбалансированный поливитаминный комплекс'],
                ['prod-008', 'Витамин D3 2000 IU', 'Витамакс', 'Витамины', 22000, 1100, 'Холекальциферол для костей и иммунной системы'],
                ['prod-011', 'Ибупрофен 400 мг', 'Узфарм', 'Обезболивающие', 7000, 2500, 'Противовоспалительный анальгетик'],
                ['prod-012', 'Парацетамол 500 мг', 'Узфарм', 'Обезболивающие', 5000, 3000, 'Классическое жаропонижающее и болеутоляющее'],
                ['prod-016', 'Натрия хлорид 0.9%', 'Узфарм', 'Растворы', 4500, 5000, 'Физиологический раствор для инфузий'],
                ['prod-020', 'Лоратадин 10 мг', 'Узфарм', 'Антигистаминные', 6000, 2200, 'Противоаллергический препарат II поколения'],
            ];
            for (const p of prods) {
                await q('INSERT INTO products (guid, name, manufacturer, category, price, stock, description) VALUES ($1,$2,$3,$4,$5,$6,$7)', p);
            }
        }

        res.json({ success: true, message: '✅ Database initialized!' });
    } catch (e) {
        console.error('Init DB error:', e);
        res.status(500).json({ error: e.message });
    }
});

// 404 catch-all
app.all('/api/*', (req, res) => {
    res.status(404).json({
        error: 'Endpoint не найден',
        debug: {
            url: req.url,
            originalUrl: req.originalUrl,
            params: req.params
        }
    });
});

// Standalone runner setup (non-Vercel)
const PORT = process.env.PORT || 3006;
if (process.env.NODE_ENV !== 'serverless') {
    app.listen(PORT, () => {
        console.log(`🚀 STANDALONE Backend running on port ${PORT}`);
    });
}

export default (req, res) => {
    return app(req, res);
};
